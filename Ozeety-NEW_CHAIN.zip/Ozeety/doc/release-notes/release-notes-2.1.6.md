v2.1.6

Updated DNS Seed Nodes to help with connection issues.
