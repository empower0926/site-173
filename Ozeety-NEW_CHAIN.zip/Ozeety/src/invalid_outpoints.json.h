// Copyright (c) 2018 The OZEETY developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef OZEETY_INVALID_OUTPOINTS_JSON_H
#define OZEETY_INVALID_OUTPOINTS_JSON_H
#include <string>

std::string LoadInvalidOutPoints()
{
    std::string str = "[\n"
            "]";
    return str;
}

#endif //OZEETY_INVALID_OUTPOINTS_JSON_H
